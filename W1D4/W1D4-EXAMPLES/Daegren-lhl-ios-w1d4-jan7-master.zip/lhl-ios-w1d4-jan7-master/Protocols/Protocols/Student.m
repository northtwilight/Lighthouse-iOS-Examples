//
//  Student.m
//  w1d4-lecture-jan7
//
//  Created by David Mills on 2019-01-10.
//  Copyright © 2019 David Mills. All rights reserved.
//

#import "Student.h"

@implementation Student

- (float)rightFootPosition {
  return 0.5;
}

@end
