//
//  Teacher.m
//  w1d4-lecture-jan7
//
//  Created by David Mills on 2019-01-10.
//  Copyright © 2019 David Mills. All rights reserved.
//

#import "Teacher.h"

@implementation Teacher

- (float)rightFootPosition {
  return 1.0;
}

@end
