//
//  Teacher.m
//  W1D4-More-OOP
//
//  Created by Daniel Mathews on 2018-08-02.
//  Copyright © 2018 Daniel Mathews. All rights reserved.
//

#import "Teacher.h"

@implementation Teacher

-(BOOL)hasValidLicense{
  return YES;
}

- (float)rightFootPosition {
 return 1.0;
}


@end
