//
//  Dog.m
//  PetsInGeneral
//
//  Created by Sam Meech-Ward on 2019-01-10.
//  Copyright © 2019 meech-ward. All rights reserved.
//

#import "Dog.h"

@implementation Dog

- (void)doTrick {
  NSLog(@"fetch, play dead");
}

@end
