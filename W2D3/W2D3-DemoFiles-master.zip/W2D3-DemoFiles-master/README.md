# W2D3-DemoFiles

## Demo 1

=> Xcode IB tour
=> Size classes
=> XCode IB autolayout demo

2 Laws:
1. All views must have a location and size.
2. Every view must ultimately have a position relative to the root view.

=> Wabi Sabi
- demo app without AL using preview
- solve layout with IB constraints.
- NB. labels have width and height (intrinsic content size)
- Add a plain UIView and show  how it needs explicit width and height.
- Add label to UIView to demo law 2.

=> Keypad Using StackViews
- Demo IBOutlet collection
- Add multiple buttons to same action.


## Demo 2
=> Create a VC using Xib file
=> Add a view using a Xib file
=> Create an app programmatically with a UITabbarController.
=> Create an app programmtically with UINavigationController.


