//
//  SecondViewController.h
//  InterfaceBuilder
//
//  Created by Roland on 2019-01-16.
//  Copyright © 2019 Game of Apps. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SecondViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
