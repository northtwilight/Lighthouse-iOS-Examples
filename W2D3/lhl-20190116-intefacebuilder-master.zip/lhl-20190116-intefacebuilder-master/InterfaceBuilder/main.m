//
//  main.m
//  InterfaceBuilder
//
//  Created by Roland on 2019-01-16.
//  Copyright © 2019 Game of Apps. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
