//
//  ViewController.h
//  NotificationCenter
//
//  Created by David Mills on 2019-05-09.
//  Copyright © 2019 David Mills. All rights reserved.
//

#import <UIKit/UIKit.h>

NSString * const ViewControllerButtonNotification = @"ViewControllerButtonNotification";

@interface ViewController : UIViewController


@end

