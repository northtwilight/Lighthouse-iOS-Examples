//
//  ViewController.h
//  SayHelloDelegate
//
//  Created by Daniel Mathews on 2015-03-26.
//  Copyright (c) 2015 ca.lighthouselabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondViewController.h"

@interface ViewController : UIViewController <sayHelloDelegate>




@end

